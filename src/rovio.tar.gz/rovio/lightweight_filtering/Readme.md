Lightweight Filtering
=====================

This is the lightweight filtering library. It provides basic functionalities for implementing EKF and UKF filters.

Author(s): Michael Bloesch