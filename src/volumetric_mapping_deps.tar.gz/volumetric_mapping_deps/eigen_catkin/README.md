Get the newest version of Eigen from upstream 
```
<build_depend>eigen_catkin</build_depend>
```
