glog_catkin
===========

A catkin wrapper for Google glog
